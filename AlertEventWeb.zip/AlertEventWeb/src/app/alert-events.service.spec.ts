import { TestBed } from '@angular/core/testing';

import { AlertEventsServiceService } from './alert-events.service';

describe('AlertEventsServiceService', () => {
  let service: AlertEventsServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlertEventsServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

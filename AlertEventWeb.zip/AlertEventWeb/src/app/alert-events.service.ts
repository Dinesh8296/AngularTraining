import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertEventsServiceService {

  constructor(private http: HttpClient) { }
  apiUrl = 'https://alert.air-worldwide.com/api/events/';

  getAlertEvents(): Observable<any[]>{
    return this.http.get<any[]>(`${this.apiUrl}`);
  }

  getEmployees(){
    return [
      {
          "id": 1,
          "employeeName": "John Doe",
          "email": "johndoe@example.com",
          "employeeId": "EMP001",
          "phone": "1234567890"
      },
      {
          "id": 2,
          "employeeName": "Jane Smith",
          "email": "janesmith@example.com",
          "employeeId": "EMP002",
          "phone": "2345678901"
      },
      {
          "id": 3,
          "employeeName": "Robert Johnson",
          "email": "robertj@example.com",
          "employeeId": "EMP003",
          "phone": "3456789012"
      },
      {
          "id": 4,
          "employeeName": "Emily Davis",
          "email": "emilyd@example.com",
          "employeeId": "EMP004",
          "phone": "4567890123"
      },
      {
          "id": 5,
          "employeeName": "Michael Brown",
          "email": "michaelb@example.com",
          "employeeId": "EMP005",
          "phone": "5678901234"
      },
      {
          "id": 6,
          "employeeName": "Jessica Wilson",
          "email": "jessicaw@example.com",
          "employeeId": "EMP006",
          "phone": "6789012345"
      },
      {
          "id": 7,
          "employeeName": "David Martinez",
          "email": "davidm@example.com",
          "employeeId": "EMP007",
          "phone": "7890123456"
      },
      {
          "id": 8,
          "employeeName": "Sarah Anderson",
          "email": "saraha@example.com",
          "employeeId": "EMP008",
          "phone": "8901234567"
      },
      {
          "id": 9,
          "employeeName": "Daniel Thomas",
          "email": "danielt@example.com",
          "employeeId": "EMP009",
          "phone": "9012345678"
      },
      {
          "id": 10,
          "employeeName": "Laura Jackson",
          "email": "lauraj@example.com",
          "employeeId": "EMP010",
          "phone": "0123456789"
      }
    ]
  }
}

import { Component } from '@angular/core';
import { AlertEventsServiceService } from '../alert-events.service';
import { NgFor } from '@angular/common';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [NgFor],
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent {
  constructor (private _alertEvents:AlertEventsServiceService){};
  employeeDetails: any[]= [];

  ngOnInit() {
      this.employeeDetails=this._alertEvents.getEmployees();
      // this._alertEvents.getEmployees().subscribe((data: any[]) => {
      //   this.employeeDetails = data;
      // });
  }
}

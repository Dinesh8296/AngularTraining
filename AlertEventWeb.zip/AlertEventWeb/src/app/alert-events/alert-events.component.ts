import { Component } from '@angular/core';
import { AlertEventsServiceService } from '../alert-events.service';
import { NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-alert-events',
  standalone: true,
  imports: [NgFor,NgIf],
  templateUrl: './alert-events.component.html',
  styleUrl: './alert-events.component.css'
})
export class AlertEventsComponent {
  constructor (private _alertEvents:AlertEventsServiceService){};
  alertEvents: any[]= [];
  employeeDetails: any[]= [];

  ngOnInit() {
    this._alertEvents.getAlertEvents().subscribe((data: any[]) => {
      this.alertEvents = data;

      this.employeeDetails=this._alertEvents.getEmployees();
    });
  }
}

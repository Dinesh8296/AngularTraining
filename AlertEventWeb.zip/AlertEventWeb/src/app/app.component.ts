import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AlertEventsComponent } from './alert-events/alert-events.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { style } from '@angular/animations';
import { NgFor,NgIf } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet,AlertEventsComponent,EmployeeListComponent,AddEmployeeComponent,NgIf],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'AlertEventWeb';

}
